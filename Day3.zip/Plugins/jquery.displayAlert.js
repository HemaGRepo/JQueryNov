(function($){
    $.displayAlert=function(message){
        alert("The Message is "+message)
    };
})(jQuery);
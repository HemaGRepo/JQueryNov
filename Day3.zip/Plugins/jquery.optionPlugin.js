(function($){
 $.fn.optionPlugin=function(options){
     var defaults={    
         fg:'green',
         bg:'yellow'
     };

     var option=$.extend(defaults,options);

     return this.each(function(){
        $(this).css({
            'font-weight':'bold',
            'color':option.fg,
            'background-color':option.bg
        });
    });
 }
})(jQuery)
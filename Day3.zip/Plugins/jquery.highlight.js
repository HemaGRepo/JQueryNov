(function($){
    $.fn.highlight=function(bg,fg){
        return this.each(function(){
            $(this).css({
                'color':fg,
                'background-color':bg
            });
        });
    }
})(jQuery)